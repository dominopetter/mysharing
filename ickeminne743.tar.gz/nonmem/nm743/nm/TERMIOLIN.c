/*
!*********************************COPYRIGHT******************************************
!                                                                                   !
!       THE NONMEM SYSTEM MAY BE DISTRIBUTED ONLY BY ICON DEVELOPMENT               !
!       SOLUTIONS.                                                                  !
!                                                                                   !
!       COPYRIGHT BY ICON DEVELOPMENT SOLUTIONS                                     !
!       2009-2011 ALL RIGHTS RESERVED.                                              !
!                                                                                   !
!************************************************************************************
*/

#include <unistd.h>
#include <termios.h>
#include <sys/types.h>


int peekcharqq2(void) {
struct termios old, new;
struct timeval zero;
int r;
fd_set readset;

    tcgetattr(STDIN_FILENO, &old);

    new = old;
    new.c_lflag &= ~(ICANON | ECHO);

    tcsetattr(STDIN_FILENO, TCSANOW, &new);

    FD_ZERO(&readset);
    FD_SET(STDIN_FILENO, &readset);

    zero.tv_sec  = 0;
    zero.tv_usec = 0;

    select(STDIN_FILENO+1, &readset, NULL, NULL, &zero);
    r = FD_ISSET(STDIN_FILENO, &readset);
    tcsetattr(STDIN_FILENO, TCSANOW, &old);
    return r;
}




int getcharqq2(void) {
struct termios old, new;
unsigned char c = 0;
int r;

    tcgetattr(STDIN_FILENO, &old);

    new = old;
    new.c_lflag &= ~(ICANON | ECHO);

    new.c_cc[VMIN]  = 1;
    new.c_cc[VTIME] = 0;

    tcsetattr(STDIN_FILENO, TCSANOW, &new);
    r = (read(STDIN_FILENO, &c, 1) < 0)	? -1 : c;

    tcsetattr(STDIN_FILENO, TCSANOW, &old);

    return r;
}




