/*
!*********************************COPYRIGHT******************************************
!                                                                                   !
!       THE NONMEM SYSTEM MAY BE DISTRIBUTED ONLY BY ICON DEVELOPMENT               !
!       SOLUTIONS.                                                                  !
!                                                                                   !
!       COPYRIGHT BY ICON DEVELOPMENT SOLUTIONS                                     !
!       2009-2011 ALL RIGHTS RESERVED.                                              !
!                                                                                   !
!************************************************************************************
*/

int peekcharqq2(void) {
int kbhiti;
kbhiti=kbhit();
return kbhiti;
}

int getcharqq2(void) {
int getchi;
getchi=getch();
return getchi;
}

