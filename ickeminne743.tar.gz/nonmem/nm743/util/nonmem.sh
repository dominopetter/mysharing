#!/bin/bash
./$3 $*
# grep "Stop Time:" $2 >& /dev/null
# if [ $? -ne 0] && [ -e OUTPUT ]; then
status=$?
# Manager returns status 0, while workers return status 1.  Only have manager do the finish up
if [ ! $status -eq 1 ]; then
# if [ -e OUTPUT ]; then
echo Stop Time: >stop.tmp
date >date.tmp
cat $2 OUTPUT stop.tmp date.tmp >trash.tmp
cp trash.tmp $2
fi

