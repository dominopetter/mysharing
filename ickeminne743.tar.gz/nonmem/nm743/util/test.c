#include <stdio.h>
 
int main(void)
{
    printf("ok\n");
    return 0;
}

