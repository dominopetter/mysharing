#!/bin/bash
echo Node location `hostname`/"$PWD"
#LD_LBRARY_PATH=.:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH
./$3 $*
# grep "Stop Time:" $2 >& /dev/null
# if [ $? -ne 0] && [ -e OUTPUT ]; then
status=$?
# Manager returns status 0, while workers return status 1.  Only have manager do the finish up
if [ ! $status -eq 1 ]; then
# if [ -e OUTPUT ]; then
echo Stop Time: >stop.tmp
date >date.tmp
cat $2 OUTPUT stop.tmp date.tmp >trash.tmp
cp trash.tmp $2
sleep 5.0
#touch condorabortm.sig
#sleep 5.0
exit 0
fi
# sleep 10.0
exit 0

